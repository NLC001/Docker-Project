<?php

function redirectButton()
{
    echo '<a href="index.php" class="redirect-button">Go Back to Home</a>';
}
